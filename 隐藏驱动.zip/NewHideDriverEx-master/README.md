# NewHideDriverEx
Hide Driver By MiProcessLoaderEntry (no trigger patchguard)  
# Support SEH (>= win10 15063 trigger patchguard)  

# Tested
## win7 x64
## win10 14393 x64
## win10 15063 x64
## win10 16299 x64

This project only provides ideas and will not be updated.  

Focus on projects that have been updated:  

https://github.com/Sqdwr/HideDriver
